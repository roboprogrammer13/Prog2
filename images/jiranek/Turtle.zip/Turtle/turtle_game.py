import turtle

# Nastavení okna
window = turtle.Screen()
window.title("Minihra - Želva")
window.bgcolor("lightblue")
window.setup(width=800, height=600)

# Nastavení souřadnicového systému (hodně oddálený pohled - obrovská kreslící plocha)
window.setworldcoordinates(-1000, -750, 1000, 750)

# Hranice pro kontrolu pozice želvy (neviditelné)
MIN_X = -980
MAX_X = 980
MIN_Y = -730
MAX_Y = 730

# Vytvoření želvy
zelva = turtle.Turtle()
zelva.shape("turtle")
zelva.color("red")
zelva.pensize(3)
zelva.speed(0)

# Barvy k dispozici
barvy = ["red", "blue", "green", "yellow", "orange", "purple", "pink", "black"]
aktualni_barva_index = 0

# Funkce pro kontrolu hranic
def kontrola_hranic():
    x, y = zelva.xcor(), zelva.ycor()
    
    # Kontrola X souřadnice
    if x < MIN_X:
        zelva.setx(MIN_X)
    elif x > MAX_X:
        zelva.setx(MAX_X)
    
    # Kontrola Y souřadnice
    if y < MIN_Y:
        zelva.sety(MIN_Y)
    elif y > MAX_Y:
        zelva.sety(MAX_Y)

# Funkce pro pohyb
def pohyb_nahoru():
    zelva.setheading(90)
    zelva.forward(20)
    kontrola_hranic()

def pohyb_dolu():
    zelva.setheading(270)
    zelva.forward(20)
    kontrola_hranic()

def pohyb_vlevo():
    zelva.setheading(180)
    zelva.forward(20)
    kontrola_hranic()

def pohyb_vpravo():
    zelva.setheading(0)
    zelva.forward(20)
    kontrola_hranic()

# Funkce pro změnu barvy
def zmen_barvu():
    global aktualni_barva_index
    aktualni_barva_index = (aktualni_barva_index + 1) % len(barvy)
    nova_barva = barvy[aktualni_barva_index]
    zelva.color(nova_barva)
    print(f"Barva změněna na: {nova_barva}")

# Funkce pro vymazání plátna
def vymaz_platno():
    zelva.clear()
    zelva.penup()
    zelva.home()
    zelva.pendown()

# Funkce pro zvednutí/spuštění pera
pero_dole = True
def prepni_pero():
    global pero_dole
    if pero_dole:
        zelva.penup()
        pero_dole = False
        print("Pero zvednuté - želva nekreslí")
    else:
        zelva.pendown()
        pero_dole = True
        print("Pero spuštěné - želva kreslí")

# Funkce pro rychlé vypnutí/zapnutí kreslení (klávesa K)
def prepni_kresleni():
    global pero_dole
    if pero_dole:
        zelva.penup()
        pero_dole = False
        print("❌ KRESLENÍ VYPNUTO - želva se pohybuje bez kreslení")
    else:
        zelva.pendown()
        pero_dole = True
        print("✅ KRESLENÍ ZAPNUTO - želva zase kreslí")

# Funkce pro kreslení tvarů
def nakresli_ctverec():
    print("Kreslím čtverec...")
    for _ in range(4):
        zelva.forward(100)
        zelva.right(90)

def nakresli_obdelnik():
    print("Kreslím obdélník...")
    for _ in range(2):
        zelva.forward(150)
        zelva.right(90)
        zelva.forward(80)
        zelva.right(90)

def nakresli_trojuhelnik():
    print("Kreslím trojúhelník...")
    for _ in range(3):
        zelva.forward(100)
        zelva.right(120)

def nakresli_kruh():
    print("Kreslím kruh...")
    zelva.circle(50)

def nakresli_sestiuhelnik():
    print("Kreslím šestiúhelník...")
    for _ in range(6):
        zelva.forward(70)
        zelva.right(60)

def nakresli_osmiuhelnik():
    print("Kreslím osmiúhelník...")
    for _ in range(8):
        zelva.forward(50)
        zelva.right(45)

def nakresli_hvezdu():
    print("Kreslím hvězdu...")
    for _ in range(5):
        zelva.forward(100)
        zelva.right(144)

# Přiřazení kláves k funkcím
window.listen()
window.onkey(pohyb_nahoru, "Up")
window.onkey(pohyb_dolu, "Down")
window.onkey(pohyb_vlevo, "Left")
window.onkey(pohyb_vpravo, "Right")
window.onkey(zmen_barvu, "space")  # Mezerník pro změnu barvy
window.onkey(vymaz_platno, "c")     # C pro vymazání
window.onkey(prepni_pero, "p")      # P pro zvednutí/spuštění pera
window.onkey(prepni_kresleni, "k")  # K pro rychlé vypnutí/zapnutí kreslení

# Klávesy pro kreslení tvarů
window.onkey(nakresli_ctverec, "1")      # 1 pro čtverec
window.onkey(nakresli_obdelnik, "2")     # 2 pro obdélník
window.onkey(nakresli_trojuhelnik, "3")  # 3 pro trojúhelník
window.onkey(nakresli_kruh, "4")         # 4 pro kruh
window.onkey(nakresli_sestiuhelnik, "5") # 5 pro šestiúhelník
window.onkey(nakresli_osmiuhelnik, "6")  # 6 pro osmiúhelník
window.onkey(nakresli_hvezdu, "7")       # 7 pro hvězdu

# Zobrazení instrukcí
print("=" * 50)
print("OVLÁDÁNÍ:")
print("Šipky - pohyb želvy")
print("MEZERNÍK - změna barvy čáry")
print("P - zvednutí/spuštění pera")
print("K - RYCHLÉ vypnutí/zapnutí kreslení")
print("C - vymazání plátna")
print("")
print("AUTOMATICKÉ TVARY:")
print("1 - čtverec")
print("2 - obdélník")
print("3 - trojúhelník")
print("4 - kruh")
print("5 - šestiúhelník")
print("6 - osmiúhelník")
print("7 - hvězda")
print("=" * 50)
print(f"Aktuální barva: {barvy[aktualni_barva_index]}")

# Udržení okna otevřeného
window.mainloop()
